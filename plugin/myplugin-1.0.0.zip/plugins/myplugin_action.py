# Minimal KiCad pcbnew Action Plugin (SWIG runtime)
import pcbnew
from pcbnew import ActionPlugin

class MyPlugin(ActionPlugin):
    def defaults(self):
        self.name = "My Awesome KiCad Plugin"
        self.category = "Modify PCB"
        self.description = "Demo action plugin installed via PCM"
        self.show_toolbar_button = True
        self.icon_file_name = "myplugin_toolbar.png"  # 24x24 icon in same dir

    def Run(self):
        board = pcbnew.GetBoard()
        pcbnew.wxMessageBox(f"Board title: {board.GetTitle()}")

MyPlugin().register()
