# Required by KiCad PCM for plugin packages
